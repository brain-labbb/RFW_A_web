"""Directed 3D editing and visualization for structured articulated templates."""

from __future__ import annotations

__version__ = "0.1.0"

__all__ = ["__version__"]
