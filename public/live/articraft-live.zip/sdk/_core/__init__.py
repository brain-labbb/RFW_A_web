"""Canonical shared SDK implementation."""
